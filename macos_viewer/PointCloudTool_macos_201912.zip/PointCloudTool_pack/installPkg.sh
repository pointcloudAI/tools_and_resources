pip install libusb1
pip install opencv-python
pip install PyOpenGL
pip install PySide2==5.11.2
pip install git+https://github.com/pyqtgraph/pyqtgraph
