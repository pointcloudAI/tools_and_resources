## Mac版本点云可视化工具使用指南

1. 先安装python3.7.2 
2. 然后执行installPkg.sh安装依赖库
3. 在命令行下面执行 run.sh脚本


