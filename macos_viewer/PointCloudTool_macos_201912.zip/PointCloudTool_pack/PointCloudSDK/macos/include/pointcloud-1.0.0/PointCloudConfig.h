/*
 * PointCloud Lib component.
 *
 * Copyright (c) 2018 PointCloud.ai Inc.
 */

#ifndef POINTCLOUD_CONFIG_H
#define POINTCLOUD_CONFIG_H

#define POINTCLOUD_ABI_VERSION 0
#define POINTCLOUD_MAJOR_VERSION 1
#define POINTCLOUD_MINOR_VERSION 0
#define POINTCLOUD_PATCH_VERSION 0
#define POINTCLOUD_CONF_VERSION 1

#endif
