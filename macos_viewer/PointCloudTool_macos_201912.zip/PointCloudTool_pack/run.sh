#!/bin/bash
DIR=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
export POINTCLOUD_SDK_PATH="$DIR/PointCloudSDK37/macos"
#xport DYLD_LIBRARY_PATH="$DYLD_LIBRARY_PATH:$POINTCLOUD_SDK_PATH/lib"
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$POINTCLOUD_SDK_PATH/lib"
export PYTHONPATH=$POINTCLOUD_SDK_PATH/lib/python3.7
echo "$PYTHONPATH"
python ./PointCloudTool.py 
