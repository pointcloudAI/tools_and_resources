## Ubuntu PointCloudToll insatll guide

1. Install python 3.6.8
2. run installPky.sh on comman line
3. run run.sh to launcher the Viewer
