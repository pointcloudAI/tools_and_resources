#!/bin/bash
DIR=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
export POINTCLOUD_SDK_PATH="$DIR/PointCloudSDK/ubuntu"
export DYLD_LIBRARY_PATH="$DYLD_LIBRARY_PATH:$POINTCLOUD_SDK_PATH/lib"
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$POINTCLOUD_SDK_PATH/lib"
export PYTHONPATH=$POINTCLOUD_SDK_PATH/lib/python3
echo "$PYTHONPATH"
python3 ./PointCloudTool.py
