#!/usr/bin/python
#
# PointCloud Tool .
#
# Copyright (c) 2018 PointCloud.AI Inc.
#
import os
import sys
import getopt
import OpenGL
import pyqtgraph
from PointCloudAI.common.SDKSelector import SDKSelector
from PointCloudAI.dialogs.SDKSelectorDialog import SDKSelectorDialog

if 'PySide' in sys.argv:
    print("using pyside ")
if 'PySide' in sys.argv:
    from PySide import  QtCore, QtGui, QtWidgets
else:
    import PySide2
    from PySide2 import  QtCore, QtGui, QtWidgets
profection = False
debug = 3
opts, args = getopt.getopt(sys.argv[1:], 'hpd', ['profection', 'help','debug'])
print(opts )
print(args)
for key, value in opts:
    print(" key ",key ," value ",value )
    if key in ['-h', '--help']:
        print('PointCloudTools [--protection] [--help]')
        print('Parameter:')
        print('-h\tHelp')
        print('-p\tUse all function')
        print('-d\tprint debug info in console 0:CRITICAL,1:ERROR,2:WARNING,3:INFO, 4:DEBUG')
        sys.exit(0)
    if key in ['-p', '--protection']:
        profection = True

    if key in ['-d', '--debug']:
        debug = 4

print(sys.version_info)
print(pyqtgraph.__version__)
print(PySide2.__version__)
print(OpenGL.__version__)
print("sys.argv ", sys.argv)
app = QtWidgets.QApplication(sys.argv)

SDKSelector.initEnvironment()
PointCloud = SDKSelectorDialog.interactiveGetSDK(SDKSelector.getSDK(), True)
cameraSystem = None
if PointCloud is None:
    pass
else:
    cameraSystem = PointCloud.CameraSystem()

    from PointCloudAI.MainWindow import MainWindow
    from PointCloudAI.common.about import *

    PointCloud.cvar.logger.setDefaultLogLevel(int(debug))
    cameraSystem = PointCloud.CameraSystem()

    if os.name == 'nt':
        # This is needed to display the app icon on the taskbar on Windows 7
        import ctypes
        myappid = 'PointCloudAI.tools' + VERSION_NUMBER   # arbitrary string
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)

    window = None

    def createWindow():
        global window
        if window is None:
            window = MainWindow(cameraSystem, profection)

createWindow()
window.show()
r = app.exec_()
del cameraSystem

sys.exit()
